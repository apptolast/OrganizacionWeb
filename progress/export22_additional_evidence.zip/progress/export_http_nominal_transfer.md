# HTTP de export_data

## Preparación y propiedad

Contrato22 aprobado cc78396. Trabajo C limitado al adaptador HTTP y sus pruebas,
con el mínimo soporte de cabeceras de seguridad que un fallo real exija.
A conserva aplicación, dominio, persistencia y ApplicationConfiguration.
Ponytail full/Caveman lite: reutilizar MVC, seguridad y problemas existentes;
no crear puertos sustitutos ni otra serialización del documento.

A reserva Gradle para sus ciclos iniciales. Esta preparación sólo lee fuentes;
no ejecuta pruebas ni acredita GREEN. El puerto anunciado es
ExportDataUseCase.prepare(owner), con PreparedExport ya completo y acotado,
filename/contentLength/writeTo(OutputStream). Se esperará el corte compilable
y sus excepciones reales antes del primer test MVC. No copiar WIP ni inventar beans.

## Hallazgos del recorrido existente

- SecurityConfiguration emite 401 UNAUTHENTICATED antes del handler.
  La discrepancia AUTHENTICATION_REQUIRED del contrato fue comunicada a root,
  quien coordina su corrección documental. No requiere cambiar el código global.
- GET no exige CSRF. OriginGuard sólo comprueba escrituras; no se abre CORS.
- SessionFailureFilter se ejecuta antes del repositorio de sesiones. Ante fallo
  no comprometido hace reset y emite 503 SESSION_UNAVAILABLE con no-store.
  No debe convertirse en STORAGE_UNAVAILABLE, que corresponde a preparar datos.
- ApiErrors ya representa problemas y StorageUnavailableException sin datos
  privados. El fallback general convierte excepciones no tratadas en 500:
  HEAD/métodos y negociación22 necesitan oráculos explícitos, no herencia asumida.
- CustomizationController usa HeaderContentNegotiationStrategy y especificidad
  sin calidad para seleccionar la calidad efectiva JSON. Es el patrón local
  pertinente; exportación distingue Accept mal formado400 de no aceptable406.
- MVC de CustomizationApiTest importa SecurityConfiguration y usa puertos reales
  mockeados. Es evidencia HTTP con filtros, no socket, PostgreSQL ni proxy reales.

## Secuencia acotada de ciclos

1. Nominal s20: bytes exactos proporcionados por el puerto, owner del Principal,
   nombre seguro y longitud exacta UTF-8, attachment único, no compresión/ETag.
   Preparar debe terminar antes de comprometer200; HTTP no reconstruye el JSON.
2. s18/s21: autenticación antes de consulta, query incluso vacío, body no vacío
   frente a longitud cero. Verificar ausencia de interacción con prepare en
   rechazos; los problemas deben conservar códigos, privacidad y precedencia.
3. s19: Accept ausente, wildcard, q0 específico y admisión específica frente a
   wildcard0; sintaxis inválida separada. Accept-Encoding debe admitir identity
   implícita y rechazar su exclusión. Reutilizar parsers instalados, sin otro
   parser general ni cambio de negociación de rutas anteriores.
4. HEAD405/Allow GET y cuerpo vacío sin preparar; métodos restantes conservan
   primero seguridad. s33 no debe activar304 ni perder el documento por headers
   condicionales. Los casos irán uno a uno, sin matriz transversal duplicada.
5. Errores413 y503 desde excepciones reales de A, sin archivo ni información
   interna. Separar fallo previo de sesión de fallo de preparación.
6. Cabeceras no-store, private, no-transform y nosniff también en401/403/405/503
   previos al handler. Primero medir; si fallan, soporte limitado a la ruta exacta
   de exportación y capaz de conservarlas tras reset, sin alterar respuestas
   ajenas. Un advice de controlador solo no acredita errores de filtros.

Cada ciclo registrará test y comando focal, resultado real y cambio mínimo.
Un caso inicialmente GREEN se documentará así. Habrá una regresión del paquete
al freeze, coordinada con A; no campañas globales ni mutación en esta fase.
La conservación de Content-Length/no-transform en proxy requiere comprobación
integrada posterior y no se atribuirá al slice MVC.

## Ciclo 1 — s20, transporte nominal

Puerto real recibido del corte nominal de A: PreparedExport expone filename,
contentLength y writeTo(OutputStream) throws IOException. El primer test MVC
usa una implementación local de ese puerto de salida con bytes UTF-8 conocidos;
no duplica un modelo productivo ni valida aquí las catorce colecciones.

RED cb3faf EXIT1: ExportDataController aún no existe y el test no compila.
Log export_http_s20_red.log. GREEN f26b26 EXIT0, 1/1: controlador síncrono
delega prepare al Principal antes de escribir cabeceras o cuerpo y transmite
los bytes preparados sin reconstrucción. Oráculos: bytes exactos con Unicode
y long textual, longitud en bytes, nombre, attachment único, tipo, privacidad,
nosniff y ausencia de encoding/ETag. Log export_http_s20_green.log.

Comando de ambos: backend/gradlew.bat test --tests
com.apptolast.organization.adapter.ExportDataApiTest --console=plain.
Sin PostgreSQL, proxy ni socket acreditados. Validación, negociación y headers
de errores siguen pendientes; no declarar HTTP completo. Gradle quedó libre
tras GREEN y root pidió traslado a un worktree aislado antes de otro ciclo.
