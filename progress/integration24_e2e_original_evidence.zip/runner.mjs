import {mkdirSync,writeFileSync,readFileSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createServer} from 'node:net';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root=resolve(process.argv[2]);const port=Number(process.argv[3]);
if(!root.endsWith('OrganizacionWeb-integration-e2e')||!Number.isInteger(port)||port<1024||port>65535||[8080,18080,18081].includes(port))throw new Error('Invalid isolated E2E root or port');
const {run}=await import(pathToFileURL(join(root,'scripts/project.mjs')));
const proof=resolve(root,'../deployment-preparation/integration24-e2e-original');mkdirSync(proof,{recursive:true});
const scratch=join(root,'.e2e-work','integration-'+process.pid);mkdirSync(scratch,{recursive:true});const environmentFile=join(scratch,'test.env');
const project='organizationweb-e2e-integration-'+process.pid;const origin=`http://127.0.0.1:${port}`;
const env={...process.env,DB_USERNAME:'e2e_user',DB_PASSWORD:'e2e-only-database',APP_AUTH_USERNAME:'e2e-user',APP_AUTH_PASSWORD:'e2e-only-password',WEB_PORT:String(port),APP_PUBLIC_ORIGIN:origin,APP_MAX_ACTIVE_PROJECTS:'3',E2E_BASE_URL:origin,E2E_COMPOSE_PROJECT:project,E2E_ENV_FILE:environmentFile};
writeFileSync(environmentFile,`DB_USERNAME=e2e_user\nDB_PASSWORD=e2e-only-database\nAPP_AUTH_USERNAME=e2e-user\nAPP_AUTH_PASSWORD=e2e-only-password\nWEB_PORT=${port}\nAPP_PUBLIC_ORIGIN=${origin}\n`);
const compose=['compose','--env-file',environmentFile,'-p',project,'-f',join(root,'docker-compose.yml')];
const files=[...new Set([...execFileSync('git',['ls-files','frontend','backend/src/main','deploy','docker-compose.yml','scripts/project.mjs','scripts/session-client.mjs','package.json','pnpm-lock.yaml'],{cwd:root,encoding:'utf8'}).trim().split(/\r?\n/),'e2e/integration-api.spec.mjs'])].filter(name=>!name.includes('/V14__')).sort();
const snapshot=()=>files.map(path=>({path,sha256:createHash('sha256').update(readFileSync(join(root,path))).digest('hex')}));
const before=snapshot();writeFileSync(join(proof,'inputs_before.json'),JSON.stringify(before,null,2));writeFileSync(join(proof,'run.json'),JSON.stringify({head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),project,port,excluded:'Protected V14 is not read or hashed.',spec:before.find(row=>row.path==='e2e/integration-api.spec.mjs')},null,2));
const probe=createServer();await new Promise((yes,no)=>{probe.once('error',no);probe.listen(port,'127.0.0.1',yes)});await new Promise(yes=>probe.close(yes));
let code=0;
try{
 run('docker',[...compose,'up','--build','-d','--wait','--wait-timeout','180'],{cwd:root,env});
 let ready=false;for(let i=0;i<90;i++){try{const response=await fetch(origin+'/api/session',{signal:AbortSignal.timeout(2000)});if(response.status===200){ready=true;break}}catch{}await new Promise(yes=>setTimeout(yes,1000));}
 if(!ready)throw new Error('API did not become ready');
 run('pnpm',['exec','playwright','test','e2e/integration-api.spec.mjs','--output','.e2e-work/integration-real-original'],{cwd:root,env});
}catch(error){console.error(error.message);code=1;}
finally{
 try{run('docker',[...compose,'down','--volumes','--remove-orphans'],{cwd:root,env})}catch(error){console.error(error.message);code=1;}
 const after=snapshot();writeFileSync(join(proof,'inputs_after.json'),JSON.stringify(after,null,2));if(JSON.stringify(before)!==JSON.stringify(after)){console.error('E2E inputs changed');code=1;}
 writeFileSync(join(proof,'run.exit'),String(code));process.exitCode=code;
}
