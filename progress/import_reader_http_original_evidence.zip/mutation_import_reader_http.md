# Mutación de importación23: lector y HTTP

PASS en ambos focos oficiales sobre commit 37d02a47f3080166a7199af8003f84f9c009000a. Ejecución secuencial, cuatro workers y umbral80, sin exclusiones nuevas ni modificaciones durante las campañas. Cada captura acredita 496 entradas idénticas antes/después.

| Foco | Killed/total | Conservador | Survived | NoCoverage | Otros | EXIT |
| --- | --- | --- | --- | --- | --- | --- |
| Reader y decoder | 135/161 | 83,850931677 % | 15 | 11 | 0 | 0 |
| HTTP y aplicación | 56/56 | 100 % | 0 | 0 | 0 | 0 |

Originales separados en progress/import_reader_pit_original y progress/import_http_pit_original: run.log, run.exit, inputs_before.json, inputs_after.json, results.json y report/ completo XML/HTML. Reader conserva además inventory.json y residues.json con firmas originales. No se suman puntuaciones ni se reclasifica ningún estado. Duraciones Gradle28s y32s; análisis PIT16s y20s. Nginx se acredita mediante los sockets previos, no con esta campaña Java. Persistencia y el futuro validador de personalización quedan fuera de estos dos resultados.

## Revisión acotada de los 26 residuos del lector

Las firmas exactas están en residues.json; se agrupan aquí por comportamiento. La lectura del código original no demuestra un defecto productivo nuevo. Se conservan los huecos sin perseguir100 % ni repetir la campaña aprobada.

- ImportJsonReader.readCount, línea278, retorno null cambiado por0: falta un oráculo directo de count no numérico en una colección vacía. El original devuelve null y rechaza el sobre; el mutante podría aceptar0. Líneas283/286 sin cobertura: faltan variantes de count negativo/fuera de rango/fracción con hash correcto. La frontera100000 de línea282 también carece de distinción directa. Son límites de pruebas, no evidencia de aceptación incorrecta por el original.
- boundedIntegerToken, líneas221/224/229/246: sobreviven fronteras de los19 dígitos significativos y variantes de escala. Las pruebas existentes distinguen cero, signo, exponente compensado y fracción; no todas las fronteras internas del superset de representación. El contrato de cada fila sigue validando su rango después del hash. No se declara equivalencia universal de estos mutantes.
- readCounts líneas261/269: cambios a mapa vacío o límite14 quedan rechazados también por la comprobación posterior de las14 claves/conteos. Defensas redundantes en el recorrido; los estados originales permanecen Survived.
- ImportReceiptDecoder.integers línea88: int/long en los extremos Integer producen el mismo número JSON durable. Las tres mutaciones sin cobertura de su rama array línea97 pertenecen a una forma que los recibos cerrados válidos no contienen; extras se rechazan por roundtrip. No se elimina esa rama ni se descuenta del denominador.
- ImportJsonReader$1 líneas90/97/102: fronteras del umbral interno1000 y recorrido de mantisa no cambian los límites contractuales del archivo. Falta cobertura de getBigIntegerValue nativo, línea92; el caso largo sí comprueba rechazo previo a conversión arbitraria. No se infiere cobertura exhaustiva del parser.
- CountedInput.read() líneas306–308: cinco mutantes sin cobertura, porque el parser utiliza lectura por bloque. El overload por bloque y el límite32MiB están ejercidos. Frontera count>0 de línea314: sumar0 conserva el contador, candidato equivalente local; continúa incluido.

No hubo Timeout, MemoryError, RunError ni NonViable. Los informes originales y los hashes se preservan antes de continuar TDD en clases nuevas.
