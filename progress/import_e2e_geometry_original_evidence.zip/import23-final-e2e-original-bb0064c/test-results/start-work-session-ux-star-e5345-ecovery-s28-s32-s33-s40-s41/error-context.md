# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: start-work-session-ux.spec.mjs >> start_work_session: responsive states preserve controls feedback and recovery @s28 @s32 @s33 @s40 @s41
- Location: e2e\start-work-session-ux.spec.mjs:13:1

# Error details

```
Test timeout of 120000ms exceeded.
```

```
Error: page.setViewportSize: Target page, context or browser has been closed
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Saltar al contenido" [ref=e4] [cursor=pointer]:
    - /url: "#proyectos"
  - complementary [ref=e5]:
    - generic [ref=e6]:
      - generic [aria-hidden] [ref=e7]: o.
      - generic [ref=e8]: OrganizationWeb
    - paragraph [ref=e9]: TU ESPACIO
    - navigation "Principal" [ref=e10]:
      - link "Hoy" [ref=e11] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=e12]: ◉
        - text: Hoy
      - link "Proyectos" [ref=e13] [cursor=pointer]:
        - /url: /proyectos
        - generic [aria-hidden] [ref=e14]: ▦
        - text: Proyectos
      - link "Disponibilidad" [ref=e16] [cursor=pointer]:
        - /url: /disponibilidad
        - generic [aria-hidden] [ref=e17]: ◷
        - text: Disponibilidad
      - link "Historial" [ref=e18] [cursor=pointer]:
        - /url: /historial
      - link "Revisión semanal" [ref=e19] [cursor=pointer]:
        - /url: /revision-semanal
      - link "Apariencia" [ref=e20] [cursor=pointer]:
        - /url: /apariencia
      - link "Exportación" [ref=e21] [cursor=pointer]:
        - /url: /exportacion
      - link "Importación" [ref=e22] [cursor=pointer]:
        - /url: /importacion
        - generic [aria-hidden] [ref=e23]: ↑
        - text: Importación
    - generic [ref=e24]:
      - text: ↗
      - paragraph [ref=e25]:
        - text: Las grandes cosasempiezan con
        - emphasis [ref=e26]: un pequeño paso.
    - generic [ref=e28]:
      - generic [aria-hidden] [ref=e29]: P
      - generic [ref=e30]:
        - text: Espacio personal
        - generic [ref=e31]: A tu ritmo
  - generic [ref=e32]:
    - banner [ref=e33]:
      - generic [ref=e34]:
        - text: Mi espacio /
        - strong [ref=e35]: Proyectos
      - generic [ref=e36]:
        - generic [aria-hidden] [ref=e37]: ●
        - text: Un paso cada día
      - button "Cerrar sesión" [ref=e38] [cursor=pointer]
    - main [ref=e39]:
      - link "Volver al proyecto" [ref=e40] [cursor=pointer]:
        - /url: /proyectos/b3c429ed-782d-4c5c-acfe-077ff9c8e149
      - article [ref=e41]:
        - heading "Preparar notas claras y conservar las decisiones para el siguiente paso, con una revisión tranquila de la información importante 🧭" [level=1] [ref=e42]
        - paragraph
        - link "Ver historial de esta tarea" [ref=e43] [cursor=pointer]:
          - /url: /historial?projectId=b3c429ed-782d-4c5c-acfe-077ff9c8e149&taskId=b4d33385-d520-4810-94b9-0e84fa312f70
        - region "Estado de la tarea" [ref=e44]:
          - heading "Estado de la tarea" [level=2] [ref=e45]
          - generic [ref=e46]: Pendiente
          - button "Completar tarea" [ref=e47] [cursor=pointer]
        - region "Historial de la tarea" [ref=e48]:
          - heading "Historial de la tarea" [level=2] [ref=e49]
          - paragraph [ref=e50]: Todavía no hay cambios de estado.
        - paragraph [ref=e51]: Sin estimación
        - region "Padre directo" [ref=e52]:
          - status [ref=e53]: Tarea principal confirmada
        - generic [ref=e54]:
          - heading "Campos personales" [level=2] [ref=e55]
          - paragraph [ref=e56]: No hay campos personales activos
        - region [ref=e57]:
          - heading "Sesión de trabajo" [active] [level=2] [ref=e58]
          - paragraph [ref=e59]: Elige cuánto tiempo te propones trabajar. El fin previsto no cierra la sesión automáticamente ni acredita tiempo neto o una tarea completada.
          - button "Actualizar sesión activa" [ref=e60] [cursor=pointer]
          - status [ref=e61]: Sesión iniciada
          - article [ref=e62]:
            - paragraph [ref=e63]:
              - text: "Inicio:"
              - time [ref=e64]: 8 de septiembre de 2026 a las 10:53:59 UTC
            - paragraph [ref=e65]: "Duración prevista: 25 minutos"
            - paragraph [ref=e66]:
              - text: "Fin previsto:"
              - time [ref=e67]: 8 de septiembre de 2026 a las 11:18:59 UTC
            - paragraph [ref=e68]: "Zona: UTC"
            - link "Ir a la tarea de esta sesión" [ref=e69] [cursor=pointer]:
              - /url: /proyectos/b3c429ed-782d-4c5c-acfe-077ff9c8e149/tareas/b4d33385-d520-4810-94b9-0e84fa312f70
          - paragraph [ref=e70]: La pausa no desplaza el fin previsto de la sesión.
          - generic [ref=e71]:
            - heading "Estado de la sesión" [level=3] [ref=e72]
            - button "Actualizar estado de la sesión" [ref=e73] [cursor=pointer]
            - paragraph [ref=e74]: En curso
            - paragraph [ref=e75]: "Tiempo de trabajo hasta la actualización: 43,161878 s"
            - paragraph [ref=e76]:
              - text: "Actualizado:"
              - time [ref=e77]: 8 de septiembre de 2026 a las 10:54:42 UTC
              - text: UTC
            - button "Pausar" [ref=e78] [cursor=pointer]
            - link "Cerrar sesión de trabajo" [ref=e79] [cursor=pointer]:
              - /url: /proyectos/b3c429ed-782d-4c5c-acfe-077ff9c8e149/tareas/b4d33385-d520-4810-94b9-0e84fa312f70/sesiones/2f4bbcf5-bcce-4fde-975d-305b2394459c
          - generic [ref=e80]:
            - heading "Fin de la sesión" [level=3] [ref=e81]
            - button "Actualizar fin acordado" [ref=e82] [cursor=pointer]
            - paragraph [ref=e83]:
              - text: "Fin previsto original:"
              - time [ref=e84]: 8 de septiembre de 2026 a las 11:18:59 UTC
              - text: UTC
            - link "Cerrar sesión de trabajo" [ref=e85] [cursor=pointer]:
              - /url: /proyectos/b3c429ed-782d-4c5c-acfe-077ff9c8e149/tareas/b4d33385-d520-4810-94b9-0e84fa312f70/sesiones/2f4bbcf5-bcce-4fde-975d-305b2394459c
            - button "Ampliar tiempo" [ref=e86] [cursor=pointer]
        - region "Bloques planificados" [ref=e87]:
          - heading "Bloques planificados" [level=2] [ref=e88]
          - paragraph [ref=e89]: Los bloques son tiempo planificado, no trabajo realizado.
          - paragraph [ref=e90]: Todavía no hay bloques planificados para esta tarea.
          - list "Bloques planificados"
          - button "Planificar bloque" [ref=e91] [cursor=pointer]
          - button "Ver cambios de bloques" [ref=e92] [cursor=pointer]
        - region [ref=e93]:
          - heading "Estado del proyecto" [level=2] [ref=e94]
          - paragraph [ref=e95]: Decide qué sigue para este proyecto, a tu ritmo.
          - generic [ref=e96]:
            - button "Activar" [ref=e97] [cursor=pointer]
            - button "Marcar terminado" [ref=e98] [cursor=pointer]
        - region [ref=e99]:
          - heading "Subtareas" [level=2] [ref=e100]
          - region "Personalización de vista" [ref=e101]:
            - button "Personalizar vista" [ref=e102] [cursor=pointer]
            - button "Gestionar campos personales" [ref=e104] [cursor=pointer]
          - paragraph [ref=e105]: Pasos pequeños, con un resultado claro.
          - paragraph [ref=e106]: Cada estimación es independiente; las subtareas no se suman automáticamente a la tarea principal.
          - paragraph [ref=e107]: Esta tarea todavía no tiene subtareas.
          - paragraph [ref=e108]: Terminar el proyecto no completa sus tareas pendientes.
          - generic [ref=e109]:
            - generic [ref=e110]:
              - generic [ref=e111]: Título de la tarea
              - textbox "Título de la tarea" [ref=e112]
            - generic [ref=e113]:
              - generic [ref=e114]: Criterio de finalización
              - textbox "Criterio de finalización" [ref=e115]
            - generic [ref=e116]:
              - generic [ref=e117]: Estimación en minutos
              - spinbutton "Estimación en minutos" [ref=e118]
            - paragraph [ref=e119]: La estimación no es tiempo trabajado.
            - button "Crear subtarea" [ref=e120] [cursor=pointer]
```

# Test source

```ts
  26  |   );
  27  |   const endpoint = `/api/v1/projects/${project.id}/tasks/${task.id}/work-sessions`;
  28  |   const engine = page.context().browser().browserType().name();
  29  |   const folder = `.e2e-work/start-work-real/${engine}/ux`;
  30  |   await mkdir(folder, { recursive: true });
  31  |   const widths = [
  32  |     320, 359, 360, 361, 390, 419, 420, 421, 480, 599, 600, 601, 699, 700, 701,
  33  |     768, 820, 999, 1000, 1001, 1024, 1099, 1100, 1101, 1280, 1440, 1599, 1600,
  34  |     1601, 1920, 2560,
  35  |   ];
  36  |   const evidence = [];
  37  |   async function inspect(state) {
  38  |     for (const width of widths) {
  39  |       await page.setViewportSize({ width, height: width === 768 ? 400 : 900 });
  40  |       const measured = await page.evaluate(() => ({
  41  |         width: innerWidth,
  42  |         height: innerHeight,
  43  |         scroll: document.documentElement.scrollWidth,
  44  |         controls: [
  45  |           ...document.querySelectorAll(
  46  |             'nav[aria-label="Principal"] a,main button,main a,main input,main select,header button',
  47  |           ),
  48  |         ]
  49  |           .filter((el) => el.getClientRects().length)
  50  |           .map((el) => {
  51  |             const box = el.getBoundingClientRect();
  52  |             return {
  53  |               name:
  54  |                 el.getAttribute("aria-label") ||
  55  |                 el.labels?.[0]?.textContent ||
  56  |                 el.textContent,
  57  |               x: box.x,
  58  |               y: box.y,
  59  |               width: box.width,
  60  |               height: box.height,
  61  |             };
  62  |           }),
  63  |       }));
  64  |       evidence.push({ state, ...measured });
  65  |       await writeFile(
  66  |         `${folder}/geometry.json`,
  67  |         JSON.stringify(evidence, null, 2),
  68  |       );
  69  |       expect(
  70  |         measured.scroll,
  71  |         `${state}:${width} page overflow`,
  72  |       ).toBeLessThanOrEqual(width);
  73  |       for (const box of measured.controls) {
  74  |         expect(
  75  |           box.x,
  76  |           `${state}:${width}:${box.name} left`,
  77  |         ).toBeGreaterThanOrEqual(0);
  78  |         expect(
  79  |           box.x + box.width,
  80  |           `${state}:${width}:${box.name} right`,
  81  |         ).toBeLessThanOrEqual(width + 1);
  82  |         expect(
  83  |           box.width,
  84  |           `${state}:${width}:${box.name} width`,
  85  |         ).toBeGreaterThanOrEqual(44);
  86  |         expect(
  87  |           box.height,
  88  |           `${state}:${width}:${box.name} height`,
  89  |         ).toBeGreaterThanOrEqual(44);
  90  |       }
  91  |       for (let a = 0; a < measured.controls.length; a++)
  92  |         for (let b = a + 1; b < measured.controls.length; b++) {
  93  |           const x = measured.controls[a],
  94  |             y = measured.controls[b];
  95  |           expect(
  96  |             Math.min(x.x + x.width, y.x + y.width) - Math.max(x.x, y.x) > 1 &&
  97  |               Math.min(x.y + x.height, y.y + y.height) - Math.max(x.y, y.y) > 1,
  98  |             `${state}:${width} overlap ${x.name}/${y.name}`,
  99  |           ).toBe(false);
  100 |         }
  101 |       if (width === 320 || width === 1440) {
  102 |         const skip = await page.locator(".skip-link").evaluate((el) => {
  103 |           const box = el.getBoundingClientRect();
  104 |           return {
  105 |             focused: document.activeElement === el,
  106 |             top: box.top,
  107 |             bottom: box.bottom,
  108 |             scrollY,
  109 |             viewportHeight: innerHeight,
  110 |           };
  111 |         });
  112 |         await writeFile(
  113 |           `${folder}/${state}-${width}-skiplink.json`,
  114 |           JSON.stringify(skip, null, 2),
  115 |         );
  116 |         if (!skip.focused) expect(skip.bottom).toBeLessThanOrEqual(0);
  117 |         await page.screenshot({
  118 |           path: `${folder}/${state}-${width}-viewport.png`,
  119 |         });
  120 |         await page.screenshot({
  121 |           path: `${folder}/${state}-${width}.png`,
  122 |           fullPage: true,
  123 |         });
  124 |       }
  125 |     }
> 126 |     await page.setViewportSize({ width: 320, height: 700 });
      |                ^ Error: page.setViewportSize: Target page, context or browser has been closed
  127 |     const axe = await new AxeBuilder({ page })
  128 |       .withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"])
  129 |       .analyze();
  130 |     await writeFile(
  131 |       `${folder}/${state}-axe.json`,
  132 |       JSON.stringify(axe.violations, null, 2),
  133 |     );
  134 |     expect(axe.violations, state).toEqual([]);
  135 |   }
  136 |   let release;
  137 |   const gate = new Promise((resolve) => {
  138 |     release = resolve;
  139 |   });
  140 |   await page.route(`**${endpoint}`, async (route) => {
  141 |     const response = await route.fetch();
  142 |     expect(response.status()).toBe(201);
  143 |     await gate;
  144 |     await route.fulfill({
  145 |       status: 503,
  146 |       contentType: "application/problem+json",
  147 |       body: JSON.stringify({
  148 |         type: "urn:organization:problem:storage_unavailable",
  149 |         title: "Almacenamiento no disponible.",
  150 |         status: 503,
  151 |         code: "STORAGE_UNAVAILABLE",
  152 |       }),
  153 |     });
  154 |   });
  155 |   await page.goto(`/proyectos/${project.id}/tareas/${task.id}`);
  156 |   const section = page.getByRole("region", {
  157 |     name: "Sesión de trabajo",
  158 |     exact: true,
  159 |   });
  160 |   const input = section.getByLabel("Duración prevista (minutos)", {
  161 |     exact: true,
  162 |   });
  163 |   await expect(input).toHaveValue("");
  164 |   await inspect("absence");
  165 |   await input.fill("25");
  166 |   const start = section.getByRole("button", {
  167 |     name: "Empezar a trabajar",
  168 |     exact: true,
  169 |   });
  170 |   await start.focus();
  171 |   await start.evaluate((button) => {
  172 |     button.addEventListener(
  173 |       "keydown",
  174 |       (event) => {
  175 |         if (event.key !== "Enter") return;
  176 |         const began = performance.now();
  177 |         const section = button.closest("section");
  178 |         const observer = new MutationObserver(() => {
  179 |           if (
  180 |             [...section.querySelectorAll('[role="status"]')].some(
  181 |               (el) => el.textContent === "Iniciando sesión de trabajo",
  182 |             )
  183 |           ) {
  184 |             window.workSessionFeedbackMs = performance.now() - began;
  185 |             observer.disconnect();
  186 |           }
  187 |         });
  188 |         observer.observe(section, {
  189 |           subtree: true,
  190 |           childList: true,
  191 |           characterData: true,
  192 |         });
  193 |       },
  194 |       { once: true },
  195 |     );
  196 |   });
  197 |   try {
  198 |     await start.press("Enter");
  199 |     await expect(
  200 |       section.getByText("Iniciando sesión de trabajo", { exact: true }),
  201 |     ).toBeVisible();
  202 |     await expect(
  203 |       section.getByText("No hay una sesión de trabajo activa.", {
  204 |         exact: true,
  205 |       }),
  206 |     ).toHaveCount(0);
  207 |     const feedback = await page.evaluate(() => window.workSessionFeedbackMs);
  208 |     expect(feedback).toBeGreaterThanOrEqual(0);
  209 |     expect(feedback).toBeLessThan(400);
  210 |     await writeFile(
  211 |       `${folder}/feedback.json`,
  212 |       JSON.stringify({ milliseconds: feedback }, null, 2),
  213 |     );
  214 |     await expect(start).toBeFocused();
  215 |     await inspect("pending");
  216 |   } finally {
  217 |     release();
  218 |   }
  219 |   const check = section.getByRole("button", {
  220 |     name: "Comprobar inicio",
  221 |     exact: true,
  222 |   });
  223 |   await expect(check).toBeVisible();
  224 |   await expect(
  225 |     section.getByText("No hay una sesión de trabajo activa.", { exact: true }),
  226 |   ).toHaveCount(0);
```